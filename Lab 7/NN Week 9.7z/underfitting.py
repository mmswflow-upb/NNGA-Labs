import tensorflow as tf
from tensorflow.keras import layers, models
import matplotlib.pyplot as plt

# ✅ Load full MNIST dataset
(x_train, y_train), (x_test, y_test) = tf.keras.datasets.mnist.load_data()

# ✅ Normalize and flatten the data
x_train = x_train / 255.0
x_test = x_test / 255.0
x_train = x_train.reshape(-1, 28 * 28)
x_test = x_test.reshape(-1, 28 * 28)

# ✅ Build a very simple model that will underfit
model = models.Sequential([
    layers.Dense(16, activation='relu', input_shape=(784,)),
    layers.Dense(10, activation='softmax')
])

model.compile(optimizer='adam',
              loss='sparse_categorical_crossentropy',
              metrics=['accuracy'])

# ✅ Train for too few epochs (to simulate underfitting)
history = model.fit(
    x_train, y_train,
    epochs=3,
    batch_size=32,
    validation_data=(x_test, y_test)
)

# ✅ Plot the results
plt.plot(history.history['accuracy'], label='Train Accuracy')
plt.plot(history.history['val_accuracy'], label='Validation Accuracy')
plt.title('Underfitting Demonstration')
plt.xlabel('Epoch')
plt.ylabel('Accuracy')
plt.legend()
plt.grid(True)
plt.show()
